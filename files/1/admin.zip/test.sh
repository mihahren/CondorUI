#!/bin/bash

echo "Do something; hit [CTRL+C] to stop!"

